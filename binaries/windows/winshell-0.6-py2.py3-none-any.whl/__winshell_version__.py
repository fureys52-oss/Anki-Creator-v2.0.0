# -*- coding: UTF8 -*-
__VERSION__ = "0.6"
__RELEASE__ = ""